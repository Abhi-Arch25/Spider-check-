﻿Spider for Rhino 8 - Version 3.4.26
Developed by Abhinay Kumar. All rights reserved.
Use is subject to the licence terms in EULA.txt.

Needs: Windows, Rhino 8.20 or newer, and a licence key.

INSTALL
  1. Extract this ZIP (right-click > Extract All).
  2. Close Rhino (save your work first).
  3. Double-click "Install Spider.cmd" and accept the licence terms (type YES).
     If Windows shows "Windows protected your PC": click "More info" > "Run anyway".
     If Rhino is still open, the installer waits: close Rhino, then press Enter.
  4. Start Rhino.
  5. Type StkLicence in Rhino and paste the licence key you received.
     The Spider toolbar and the Stk commands are then ready.
     StkLicence also shows how many days your licence has left.

UPDATE
  When a new version is out, Spider says so in Rhino (before the first Spider command,
  or any time with StkUpdate) and downloads the new ZIP when you click Yes.
  Then do INSTALL steps 1-4 with the newer version's ZIP: extract it, close Rhino,
  double-click "Install Spider.cmd", start Rhino. Your licence key and toolbar place stay;
  older Spider toolbars are removed, so only one Spider toolbar shows.

UNINSTALL
  Double-click "Uninstall Spider.cmd", or in Rhino: _PackageManager > Installed > Spider > Uninstall.

---------------------------------------------------------------------------

INSTALLATION (Deutsch)
  Entwickelt von Abhinay Kumar. Alle Rechte vorbehalten.
  Die Nutzung unterliegt den Lizenzbedingungen in EULA.txt.

  1. ZIP entpacken (Rechtsklick > Alle extrahieren).
  2. Rhino schließen (vorher speichern).
  3. "Install Spider.cmd" doppelklicken und die Lizenzbedingungen annehmen (YES eingeben).
     Falls "Der Computer wurde durch Windows geschützt" erscheint:
     "Weitere Informationen" > "Trotzdem ausführen".
     Ist Rhino noch offen, wartet das Programm: Rhino schließen, dann Enter drücken.
  4. Rhino starten.
  5. In Rhino StkLicence eingeben und den erhaltenen Lizenzschlüssel einfügen.
     Danach sind die Spider-Werkzeugleiste und die Stk-Befehle bereit.

  Aktualisieren: Schritte 1-4 mit der ZIP der neuen Version. Lizenzschlüssel und
  Position der Werkzeugleiste bleiben erhalten.

  Deinstallieren: "Uninstall Spider.cmd" doppelklicken.
