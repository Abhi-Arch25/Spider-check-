<#
One Spider toolbar. Dot-sourced by Install.ps1 and csharp\build.ps1 -Install.

Every Spider version installs into its own folder, and Rhino's saved layout (containers.xml)
kept a toolbar copy ("Spider 01", "Spider 02", ...) for each toolbar file it once opened.
Before installing, the older versions' Spider.rui files are deleted; after installing - only
while Rhino is closed, since Rhino rewrites the layout when it exits - the layout keeps one
Spider toolbar, in its saved place, showing the new version's Spider.rui. A copy of the layout before the change is kept as containers.xml.spider-backup.
#>

$SpiderId = "e857e243-22ef-4580-a7d8-80aa689d425b"

function Remove-OldSpiderToolbars {
    $versions = Join-Path $env:APPDATA "McNeel\Rhinoceros\packages\8.0\Spider"
    if (Test-Path $versions) {
        Get-ChildItem $versions -Directory | ForEach-Object { Remove-Item (Join-Path $_.FullName "Spider.rui") -Force -ErrorAction SilentlyContinue }
    }
}

# true when the layouts were checked (Rhino closed), false when Rhino runs
function Repair-SpiderToolbarLayout {
    if (Get-Process -Name Rhino -ErrorAction SilentlyContinue) { return $false }
    $settings = Join-Path $env:APPDATA "McNeel\Rhinoceros\8.0\settings"
    Get-ChildItem $settings -Directory -Filter "Scheme__*" -ErrorAction SilentlyContinue | ForEach-Object {
        $file = Join-Path $_.FullName "containers.xml"
        if (Test-Path $file) {
            try { Repair-SpiderLayoutFile $file } catch { Write-Warning "Toolbar layout not changed ($file): $($_.Exception.Message)" }
        }
    }
    return $true
}

function Repair-SpiderLayoutFile([string]$file) {
    $xml = New-Object System.Xml.XmlDocument
    $xml.PreserveWhitespace = $true
    $xml.Load($file)
    $changed = $false

    # toolbar files opened by path
    foreach ($node in @($xml.SelectNodes("//files/file_name[@plug_in_guid='$SpiderId' or @guid='$SpiderId']"))) {
        [void]$node.ParentNode.RemoveChild($node); $changed = $true
    }
    # the plug-in's toolbar file: the newest installed version's (without it Rhino shows no Spider toolbar)
    $current = Get-ChildItem (Join-Path $env:APPDATA "McNeel\Rhinoceros\packages\8.0\Spider") -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -as [version] -and (Test-Path (Join-Path $_.FullName "Spider.rui")) } |
        Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1
    $entries = @($xml.SelectNodes("//plug_in_files/file_name[@plug_in_guid='$SpiderId']"))
    foreach ($node in $entries | Select-Object -Skip 1) { [void]$node.ParentNode.RemoveChild($node); $changed = $true }
    if ($current) {
        $path = Join-Path $current.FullName "Spider.rui"
        $node = $entries | Select-Object -First 1
        if (-not $node) {
            $list = $xml.SelectSingleNode("//plug_in_files")
            if ($list) {
                $node = $xml.CreateElement("file_name")
                $node.SetAttribute("plug_in_guid", $SpiderId)
                [void]$list.AppendChild($node)
            }
        }
        if ($node -and $node.InnerText -ne $path) { $node.InnerText = $path; $changed = $true }
    }

    # one Spider toolbar window: the main one (its id is the plug-in's) or else the first
    $bars = @($xml.SelectNodes("//dock_bars/dock_bar[@source_group='$SpiderId']"))
    if ($bars.Count -eq 0) {
        # no Spider toolbar window left in the layout (Rhino then shows none, or only now and then
        # when Spider's late fallback wins the race): add one, floating and shown
        $list = $xml.SelectSingleNode("//dock_bars")
        if ($list) {
            $frag = $xml.CreateDocumentFragment()
            $frag.InnerXml = "<dock_bar guid=`"$SpiderId`" source_group_file=`"$SpiderId`" source_group=`"$SpiderId`">" +
                "<placement dock_location=`"Floating`" float_point=`"200,200`" float_size=`"420,60`" visible=`"True`" />" +
                "<tabs name=`"Spider`" selected_item=`"$SpiderId`" display_style=`"BitmapAndText`"><name><locale_1033>Spider</locale_1033></name>" +
                "<tool_bar guid=`"$SpiderId`" file=`"$SpiderId`" side_bar_file=`"$SpiderId`" /></tabs></dock_bar>"
            [void]$list.AppendChild($frag)
            $bars = @($xml.SelectNodes("//dock_bars/dock_bar[@source_group='$SpiderId']"))
            $changed = $true
        }
    }
    if ($bars.Count -gt 0) {
        $keep = $bars | Where-Object { $_.GetAttribute("guid") -eq $SpiderId } | Select-Object -First 1
        if (-not $keep) { $keep = $bars[0] }
        $removed = @()
        foreach ($bar in $bars) {
            if (-not [object]::ReferenceEquals($bar, $keep)) { $removed += $bar.GetAttribute("guid"); [void]$bar.ParentNode.RemoveChild($bar); $changed = $true }
        }
        # the kept window is shown and holds the plug-in's own toolbar file
        if ($keep.GetAttribute("source_group_file") -ne $SpiderId) { $keep.SetAttribute("source_group_file", $SpiderId); $changed = $true }
        $placement = $keep.SelectSingleNode("placement")
        if ($placement -and $placement.GetAttribute("visible") -ne "True") { $placement.SetAttribute("visible", "True"); $changed = $true }
        foreach ($tb in @($keep.SelectNodes(".//tool_bar[@guid='$SpiderId']"))) {
            foreach ($a in "file", "side_bar_file") {
                if ($tb.HasAttribute($a) -and $tb.GetAttribute($a) -ne $SpiderId) { $tb.SetAttribute($a, $SpiderId); $changed = $true }
            }
        }
        # docked places of the removed windows
        foreach ($id in $removed) {
            foreach ($ref in @($xml.SelectNodes("//dock_sites//dock_bar[@guid='$id']"))) {
                $band = $ref.ParentNode
                [void]$band.RemoveChild($ref)
                if (-not $band.SelectSingleNode("dock_bar")) { [void]$band.ParentNode.RemoveChild($band) }
            }
        }
    }

    if ($changed) {
        Copy-Item $file "$file.spider-backup" -Force
        $xml.Save($file)
        Write-Host "Rhino toolbar layout: one Spider toolbar ($file)"
    }
}
