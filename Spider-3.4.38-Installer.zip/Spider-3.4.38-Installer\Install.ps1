<#
Installs (or removes) Spider into Rhino 8 for the current Windows user.
Started by "Install Spider.cmd" / "Uninstall Spider.cmd" - no admin rights needed.
The .yak package sits next to this script.
-Update: started by Spider's "Update now" in Rhino (the terms were accepted at the first
install) - waits for Rhino to close, installs, and starts Rhino again.
#>
param([switch]$Uninstall, [switch]$Update)
$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "Spider installer"

function Stop-WithMessage([string]$text) {
    Write-Host ""
    Write-Host $text -ForegroundColor Red
    if ($Update) { Read-Host "Press Enter to close" | Out-Null }
    exit 1
}

# Rhino 8 and its package installer (Yak.exe)
$rhinoDir = $null
try { $rhinoDir = (Get-ItemProperty 'HKLM:\SOFTWARE\McNeel\Rhinoceros\8.0\Install' -ErrorAction Stop).InstallPath } catch {}
if (-not $rhinoDir) { $rhinoDir = Join-Path $env:ProgramFiles "Rhino 8" }
$yak = Join-Path $rhinoDir "System\Yak.exe"
$rhinoExe = Join-Path $rhinoDir "System\Rhino.exe"
if (-not (Test-Path $rhinoExe)) {
    Stop-WithMessage "Rhino 8 was not found on this PC. Install Rhino 8 (8.20 or newer) first."
}
$packages = Join-Path $env:APPDATA "McNeel\Rhinoceros\packages\8.0"

# Rhino's package tool; false when it is missing or fails (it crashed on a Rhino 8.29 PC: DocoptNet missing)
function Invoke-Yak([string[]]$arguments) {
    if (-not (Test-Path $yak)) { return $false }
    try { & $yak @arguments | Out-Host; return ($LASTEXITCODE -eq 0) } catch { return $false }
}

# what Yak does: the package unpacked into packages\8.0\Spider\<version>, that version named in manifest.txt
function Install-Direct($package) {
    $version = [regex]::Match($package.Name, '^spider-(\d+\.\d+\.\d+)').Groups[1].Value
    if (-not $version) { Stop-WithMessage "Cannot read the version from $($package.Name)." }
    $target = Join-Path $packages "Spider\$version"
    if (Test-Path $target) { Remove-Item $target -Recurse -Force }
    New-Item -ItemType Directory -Force $target | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($package.FullName, $target)
    [IO.File]::WriteAllText((Join-Path $packages "Spider\manifest.txt"), "$version`n", (New-Object System.Text.UTF8Encoding($false)))
}

if ($Uninstall) {
    if (-not (Invoke-Yak @("uninstall", "spider"))) {
        $folder = Join-Path $packages "Spider"
        if (-not (Test-Path $folder)) { Stop-WithMessage "Spider is not installed." }
        if (Get-Process -Name Rhino -ErrorAction SilentlyContinue) { Stop-WithMessage "Close Rhino first, then run this again." }
        Remove-Item $folder -Recurse -Force
    }
    Write-Host ""
    Write-Host "Spider was removed. Restart Rhino." -ForegroundColor Green
    exit 0
}

# the package is built against Rhino 8.20
$rhinoVersion = [version](Get-Item $rhinoExe).VersionInfo.FileVersion
if ($rhinoVersion -lt [version]"8.20") {
    Stop-WithMessage "Rhino $rhinoVersion is too old. Spider needs Rhino 8.20 or newer - update Rhino (Help > Check for Updates)."
}

# the licence terms are accepted before anything is installed
$eula = Join-Path $PSScriptRoot "EULA.txt"
if ((Test-Path $eula) -and -not $Update) {
    Write-Host ""
    Get-Content $eula -Encoding UTF8 | Write-Host
    Write-Host ""
    $answer = Read-Host "Do you accept these licence terms? Type YES to install"
    if ($answer.Trim().ToUpperInvariant() -ne "YES") { Stop-WithMessage "Not installed: the licence terms were not accepted." }
}

$package = Get-ChildItem -Path $PSScriptRoot -Filter "spider-*.yak" | Select-Object -First 1
if (-not $package) { Stop-WithMessage "The spider-*.yak file is missing next to this installer." }
Write-Host "Installing $($package.Name) into Rhino $rhinoVersion ..."

# Stueckliste 1.x / 2.x has the same plug-in id and must not be installed alongside
$old = Join-Path $packages "Stueckliste"
if (Test-Path $old) {
    Write-Host "Removing the old Stueckliste plug-in ..."
    if (-not (Invoke-Yak @("uninstall", "stueckliste"))) { Remove-Item $old -Recurse -Force -ErrorAction SilentlyContinue }
}

# one Spider toolbar: Rhino rewrites its toolbar layout when it exits, so it is closed first
. (Join-Path $PSScriptRoot "SpiderToolbar.ps1")
$started = Get-Date
$restart = $false
if ($Update) {
    Write-Host "Waiting for Rhino to close (save your work when Rhino asks) ..."
    while (Get-Process -Name Rhino -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 1 }
    # Rhino closed for the update: start it again; closed much later (save cancelled first): leave it closed
    $restart = ((Get-Date) - $started).TotalMinutes -lt 5
    Start-Sleep -Seconds 2   # Rhino's last files written
}
while (Get-Process -Name Rhino -ErrorAction SilentlyContinue) {
    Write-Host ""
    Write-Host "Rhino is open. Save your work, close Rhino, then press Enter." -ForegroundColor Yellow
    [void](Read-Host)
}
Remove-OldSpiderToolbars

if (-not (Invoke-Yak @("install", "--source=$PSScriptRoot", "spider"))) {
    Write-Host ""
    Write-Host "Rhino's package tool did not work - installing Spider directly ..." -ForegroundColor Yellow
    try { Install-Direct $package } catch { Stop-WithMessage "Installation failed: $($_.Exception.Message)" }
}
[void](Repair-SpiderToolbarLayout)

Write-Host ""
if ($Update) {
    Write-Host "Spider is updated." -ForegroundColor Green
    if ($restart) { Write-Host "Starting Rhino ..."; Start-Process $rhinoExe }
    Start-Sleep -Seconds 3
    exit 0
}
Write-Host "Spider is installed. Start Rhino - the Spider toolbar and the Stk commands are ready." -ForegroundColor Green
