@echo off
rem Double-click to install Spider into Rhino 8 (current user, no admin rights needed).
if not exist "%~dp0Install.ps1" (
    echo Please extract the whole ZIP file first, then run "Install Spider.cmd" from the extracted folder.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
echo.
pause
