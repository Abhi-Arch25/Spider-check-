@echo off
rem Double-click to remove Spider from Rhino 8.
if not exist "%~dp0Install.ps1" (
    echo Please extract the whole ZIP file first, then run "Uninstall Spider.cmd" from the extracted folder.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" -Uninstall
echo.
pause
